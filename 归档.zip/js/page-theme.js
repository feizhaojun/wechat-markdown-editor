var pageThemeObj = {
  '我的样式': '我的样式',
  default: 'default',
  jianshu: 'jianshu',
  stormzhang: 'stormzhang',
}